import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MergeSorterTest {

    @Test
    /**
     * Test One.
     */
    public void testOne() {
        int[] result = { 10, 15, 12, 4, 25 };
        MergeSorter.merge(result);

        int[] expected = { 4, 10, 12, 15, 25 };

        assertEquals(result.length, expected.length);

        for (int i = 0; i < result.length; i++) {
            assertEquals(result[i], expected[i]);
        }
    }

    /**
     * Test Two.
     */
    public void testTwo() {
        int[] result = {};
        MergeSorter.merge(result);

        int[] expected = {};

        assertEquals(result.length, expected.length);

        for (int i = 0; i < result.length; i++) {
            assertEquals(result[i], expected[i]);
        }
    }

    /**
     * Test Three.
     */
    public void testThree() {
        int[] result = { 12, 7 };
        MergeSorter.merge(result);

        int[] expected = { 7, 12 };

        assertEquals(result.length, expected.length);

        for (int i = 0; i < result.length; i++) {
            assertEquals(result[i], expected[i]);
        }
    }

}
