import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Yash Amin
 *
 */
public final class MergeSorter {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private MergeSorter() {
    }

    /**
     * Put a short phrase describing the static method myMethod here.
     */
    public static int[] merge(int[] array) {

        //Create arrays and length variable
        int length = array.length;
        int[] left = new int[length - (length / 2)];
        int[] right = new int[(length / 2)];

        //Breaking down each array
        if (array.length > 1) {
            int rightValue = 0;
            int leftValue = 0;
            for (int i = 0; i < length; i++) {
                if (i < (length - (length / 2))) {
                    left[leftValue] = array[i];
                    leftValue++;
                } else {
                    right[rightValue] = array[i];
                    rightValue++;
                }
            }
            left = merge(left);
            right = merge(right);

            //Building each array back up
            int rightIndex = 0;
            int leftIndex = 0;

            for (int k = 0; k < length; k++) {

                if (rightValue == rightIndex) {
                    array[k] = left[leftIndex];
                    leftIndex++;
                } else if (leftValue == leftIndex) {
                    array[k] = right[rightIndex];
                    rightIndex++;
                } else if (left[leftIndex] <= right[rightIndex]) {
                    array[k] = left[leftIndex];
                    leftIndex++;
                } else {
                    array[k] = right[rightIndex];
                    rightIndex++;
                }

            }
        }

        return array;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        int[] array = { 10, 15, 12, 4, 25 };
        int[] result = merge(array);

        for (int i = 0; i < result.length; i++) {
            out.print(result[i] + ",");
        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
